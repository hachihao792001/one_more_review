<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_ONE MORE REVIEW_hidden pi pi-search ab_e05d68</name>
   <tag></tag>
   <elementGuidId>8d58a367-a8c0-432e-a6a0-90b6420037a8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>hidden pi pi-search absolute right-2 top-1 md:inline-block text-white text-2xl cursor-pointer hover:text-blue-500 transition-all duration-200</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-home-page[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;home ng-tns-c59-1&quot;]/app-header[@class=&quot;ng-tns-c59-1&quot;]/div[@class=&quot;header&quot;]/div[@class=&quot;header-container&quot;]/div[@class=&quot;flex justify-end items-center flex-wrap&quot;]/span[@class=&quot;p-input-icon-right search relative&quot;]/span[@class=&quot;hidden pi pi-search absolute right-2 top-1 md:inline-block text-white text-2xl cursor-pointer hover:text-blue-500 transition-all duration-200&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span</value>
   </webElementXpaths>
</WebElementEntity>
