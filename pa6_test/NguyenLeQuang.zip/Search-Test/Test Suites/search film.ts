<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>search film</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>77d681e5-a02f-43a8-9b4f-ab129abcbdcf</testSuiteGuid>
   <testCaseLink>
      <guid>72e3014e-ae72-46c6-8ae7-71412631b9f7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/search valid with result</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>516e19ac-94a9-4d6c-b71d-47a535a15941</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/result_search</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>516e19ac-94a9-4d6c-b71d-47a535a15941</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>input</value>
         <variableId>e1f73c3f-54c3-40f7-8823-f1053e3ef9ed</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>9c7da031-a964-48f2-9dd8-43fad0b78332</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/search with no result</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>5fd91943-96b6-475d-9286-0760698c99ba</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/result_search</testDataId>
      </testDataLink>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>19816d22-3d42-49ab-8841-9511fedb67d1</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/no_result_search</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>19816d22-3d42-49ab-8841-9511fedb67d1</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>err_input</value>
         <variableId>a1bcfad8-fcd8-4294-aab4-f8cf3f896e89</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
