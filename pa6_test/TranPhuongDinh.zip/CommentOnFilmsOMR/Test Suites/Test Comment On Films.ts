<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Comment On Films</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>1b281068-6d10-4503-848e-a5a42c9e396b</testSuiteGuid>
   <testCaseLink>
      <guid>658c4a85-aa90-422d-afce-330e9e9cf2c1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Basic user input</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>036befcc-db3e-4094-9e13-404c09fc36df</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Comment Data</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>036befcc-db3e-4094-9e13-404c09fc36df</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>comment</value>
         <variableId>745b4215-f38d-4f7b-ae25-00fdd7f6d313</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>7a6a58ae-127b-4e00-bcb8-2d083caebbdb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Spamming comments</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>1aada3d6-948d-412e-b357-0257f4fbbf67</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Comment Data</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>1aada3d6-948d-412e-b357-0257f4fbbf67</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>spam</value>
         <variableId>7c45cb47-d20c-4892-9993-0e24c4150788</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
