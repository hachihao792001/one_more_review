<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Bnh lun_far fa-share-square text-2xl hove_0f3432</name>
   <tag></tag>
   <elementGuidId>70582352-f272-4329-b09d-8baf3a647ba0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[4]/div/div/button/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>far fa-share-square text-2xl hover:text-yellow-200 transition-all duration-200</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;dark&quot;]/body[1]/app-root[1]/app-film[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;film-container&quot;]/div[@class=&quot;reviews xl:p-20 lg:p-10 p-5 bg-gray-900&quot;]/div[@class=&quot;comment__form flex flex-col justify-center items-center w-full py-5&quot;]/div[@class=&quot;relative w-full lg:w-1/2&quot;]/button[@class=&quot;text-white right-2 top-1 absolute&quot;]/i[@class=&quot;far fa-share-square text-2xl hover:text-yellow-200 transition-all duration-200&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/button/i</value>
   </webElementXpaths>
</WebElementEntity>
