<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Review Films</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>4f90a07a-9e6c-4577-827b-75e2744a835e</testSuiteGuid>
   <testCaseLink>
      <guid>83002a03-1884-46f6-9242-157dd269a370</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Send Valid Review Film</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>d688ff38-13a2-4ae4-861a-b4b5c44b6bb4</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Content Review Film</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>d688ff38-13a2-4ae4-861a-b4b5c44b6bb4</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>content</value>
         <variableId>237414fb-4ecc-4330-871a-e1ac9489a312</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>7de96ccd-1a82-4aa9-873b-9bcd16a3d680</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Send Too Long Review Film</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>aded7a03-4a15-4d4b-a0b0-d41fcec68dc0</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Content Review Film</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>aded7a03-4a15-4d4b-a0b0-d41fcec68dc0</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>invalid_content</value>
         <variableId>484962a6-9d8b-4e46-9eb1-56694c404f9a</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
