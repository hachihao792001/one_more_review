<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_nh gi_pi pi-send text-4xl p-3 ml-3 hovert_c68e9d</name>
   <tag></tag>
   <elementGuidId>91deb3b1-dce3-40a3-957d-1e57acb2abc0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>pi pi-send text-4xl p-3 ml-3 hover:text-yellow-300 transition-all duration-200</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;dark&quot;]/body[1]/app-root[1]/app-film[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;film-container&quot;]/div[@class=&quot;reviews xl:p-20 lg:p-10 p-5 bg-gray-900&quot;]/div[@class=&quot;reviews__form flex flex-col justify-center items-center w-full mt-5&quot;]/div[@class=&quot;flex justify-center items-center w-full lg:w-1/2 relative mb-5&quot;]/button[@class=&quot;text-white absolute right-1&quot;]/i[@class=&quot;pi pi-send text-4xl p-3 ml-3 hover:text-yellow-300 transition-all duration-200&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//i</value>
   </webElementXpaths>
</WebElementEntity>
