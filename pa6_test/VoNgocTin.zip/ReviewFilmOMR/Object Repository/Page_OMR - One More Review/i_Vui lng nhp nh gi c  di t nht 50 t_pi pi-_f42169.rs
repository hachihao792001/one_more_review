<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Vui lng nhp nh gi c  di t nht 50 t_pi pi-_f42169</name>
   <tag></tag>
   <elementGuidId>ea50a89e-42da-4795-86f5-194c8c6ba73f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>pi pi-send text-4xl p-3 ml-3 hover:text-yellow-300 transition-all duration-200</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;dark&quot;]/body[1]/app-root[1]/app-film[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;film-container&quot;]/div[@class=&quot;reviews xl:p-20 lg:p-10 p-5 bg-gray-900&quot;]/div[@class=&quot;reviews__form flex flex-col justify-center items-center w-full mt-5&quot;]/div[@class=&quot;flex justify-center items-center w-full lg:w-1/2 relative mb-5&quot;]/button[@class=&quot;text-white absolute right-1&quot;]/i[@class=&quot;pi pi-send text-4xl p-3 ml-3 hover:text-yellow-300 transition-all duration-200&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//i</value>
   </webElementXpaths>
</WebElementEntity>
