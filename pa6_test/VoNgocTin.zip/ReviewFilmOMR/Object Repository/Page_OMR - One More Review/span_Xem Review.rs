<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Xem Review</name>
   <tag></tag>
   <elementGuidId>7df6e800-c56f-4826-b121-c57e85b35391</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.p-carousel-item.p-carousel-item-active.p-carousel-item-start.p-carousel-item-end.ng-star-inserted > div.detail.ng-tns-c59-1.ng-star-inserted > div.mt-5.mb-2.ng-tns-c59-1 > button.p-element.p-button-help.ng-tns-c59-1.p-button.p-component > span.p-button-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='pr_id_4']/div/div/div/div/div[2]/div/div/button/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-button-label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Xem Review</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pr_id_4&quot;)/div[@class=&quot;p-carousel-content&quot;]/div[@class=&quot;p-carousel-container&quot;]/div[@class=&quot;p-carousel-items-content&quot;]/div[@class=&quot;p-carousel-items-container&quot;]/div[@class=&quot;p-carousel-item p-carousel-item-active p-carousel-item-start p-carousel-item-end ng-star-inserted&quot;]/div[@class=&quot;detail ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;mt-5 mb-2 ng-tns-c59-1&quot;]/button[@class=&quot;p-element p-button-help ng-tns-c59-1 p-button p-component&quot;]/span[@class=&quot;p-button-label&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='pr_id_4']/div/div/div/div/div[2]/div/div/button/span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trailer'])[2]/following::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chủng tộc bất tử'])[1]/following::span[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ba chàng ngốc'])[1]/preceding::span[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trailer'])[3]/preceding::span[7]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/button/span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Xem Review' or . = 'Xem Review')]</value>
   </webElementXpaths>
</WebElementEntity>
