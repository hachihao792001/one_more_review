<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>fullscreen_btn</name>
   <tag></tag>
   <elementGuidId>f70aef27-e973-444c-919f-a64f59a5c270</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@class='ytp-fullscreen-button ytp-button']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//button[@class='ytp-fullscreen-button ytp-button']</value>
   </webElementXpaths>
</WebElementEntity>
