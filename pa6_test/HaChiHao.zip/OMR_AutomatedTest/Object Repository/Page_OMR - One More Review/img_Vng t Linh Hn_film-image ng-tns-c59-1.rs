<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>img_Vng t Linh Hn_film-image ng-tns-c59-1</name>
   <tag></tag>
   <elementGuidId>7813df76-31e6-4e30-a43e-31915d44ae97</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//img[@alt='Người nhện: Không còn nhà']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>img</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>film-image ng-tns-c59-1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>src</name>
      <type>Main</type>
      <value>https://www.themoviedb.org/t/p/original/1gxZrx9gL9ov2c1NpXimEUzMTmh.jpg</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>alt</name>
      <type>Main</type>
      <value>Người nhện: Không còn nhà</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;dark&quot;]/body[1]/app-root[1]/app-home-page[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;home ng-tns-c59-1&quot;]/div[@class=&quot;home-container ng-tns-c59-1&quot;]/div[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;film-container ng-tns-c59-1&quot;]/div[@class=&quot;list-container ng-tns-c59-1&quot;]/div[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;film-item relative ng-tns-c59-1&quot;]/img[@class=&quot;film-image ng-tns-c59-1&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:img</name>
      <type>Main</type>
      <value>//img[@alt='Người nhện: Không còn nhà']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/img</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//img[@src = 'https://www.themoviedb.org/t/p/original/1gxZrx9gL9ov2c1NpXimEUzMTmh.jpg' and @alt = 'Người nhện: Không còn nhà']</value>
   </webElementXpaths>
</WebElementEntity>
