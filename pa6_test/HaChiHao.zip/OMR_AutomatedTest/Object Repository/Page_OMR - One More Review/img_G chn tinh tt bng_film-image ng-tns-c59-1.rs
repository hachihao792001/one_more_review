<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>img_G chn tinh tt bng_film-image ng-tns-c59-1</name>
   <tag></tag>
   <elementGuidId>82f9bc83-9234-4e92-9208-b06b42e9f40c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//img[@alt='Diệp Vấn']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>img</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>film-image ng-tns-c59-1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>src</name>
      <type>Main</type>
      <value>https://i1.wp.com/nobiphim.com/wp-content/uploads/2019/09/Diep-Van-1-Ip-Man-2008-Poster.jpg?fit=666%2C1000&amp;ssl=1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>alt</name>
      <type>Main</type>
      <value>Diệp Vấn</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;dark&quot;]/body[1]/app-root[1]/app-home-page[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;home ng-tns-c59-1&quot;]/div[@class=&quot;home-container ng-tns-c59-1&quot;]/div[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;film-container ng-tns-c59-1&quot;]/div[@class=&quot;list-container ng-tns-c59-1&quot;]/div[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;film-item relative ng-tns-c59-1&quot;]/img[@class=&quot;film-image ng-tns-c59-1&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:img</name>
      <type>Main</type>
      <value>//img[@alt='Diệp Vấn']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/img</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//img[@src = 'https://i1.wp.com/nobiphim.com/wp-content/uploads/2019/09/Diep-Van-1-Ip-Man-2008-Poster.jpg?fit=666%2C1000&amp;ssl=1' and @alt = 'Diệp Vấn']</value>
   </webElementXpaths>
</WebElementEntity>
