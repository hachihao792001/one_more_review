<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>WatchFilmsFullScreen</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c9606516-b420-4a02-ae8b-2ed62d450d59</testSuiteGuid>
   <testCaseLink>
      <guid>526ec1b5-e57f-4cad-ade1-883b2cf07b36</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/FullScreen/WatchFilms_FullScreenTest</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c28eef17-1780-4029-9f49-38301a3e6aa2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/FullScreen/WatchFilms_FullScreenTest_2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>03ef7966-d442-489b-aea1-9bfb54fac81f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/FullScreen/WatchFilms_FullScreenTest_3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b96b28b3-0a32-4c34-bc9a-3312577b51bb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/FullScreen/WatchFilms_FullScreenTest_4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>02b905f8-4740-4802-8506-97c974535afb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/FullScreen/WatchFilms_FullScreenTest_5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
