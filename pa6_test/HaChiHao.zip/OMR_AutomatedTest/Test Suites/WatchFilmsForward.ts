<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>WatchFilmsForward</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>5083b554-e604-4e0e-a03e-79bd566c2af7</testSuiteGuid>
   <testCaseLink>
      <guid>4226db14-65dc-44aa-b725-def219724a1a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Forward/WatchFilms_ForwardTest</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>af403141-259b-452f-8be1-4d64ec545f82</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Forward/WatchFilms_ForwardTest_2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>66009486-145a-4a7f-876c-8f06b53d087c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Forward/WatchFilms_ForwardTest_3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3bfb87e3-f960-4066-abf4-3be4f0b4cbf1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Forward/WatchFilms_ForwardTest_4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0b88c7ce-1f76-4b76-879e-61147f2a90f1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Forward/WatchFilms_ForwardTest_5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
