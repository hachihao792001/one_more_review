<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Quc gia_p-dropdown-trigger-icon ng-tns_1ecff5</name>
   <tag></tag>
   <elementGuidId>9c41dad8-462c-4b69-86e5-c0c30b94d96f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.p-dropdown-trigger-icon.ng-tns-c40-4.pi.pi-chevron-down</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[2]/p-dropdown/div/div[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-dropdown-trigger-icon ng-tns-c40-4 pi pi-chevron-down</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-home-page[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;home ng-tns-c59-1&quot;]/div[@class=&quot;home-container ng-tns-c59-1&quot;]/div[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;filter-container ng-tns-c59-1&quot;]/div[@class=&quot;dropdown ng-tns-c59-1&quot;]/p-dropdown[@class=&quot;p-element p-inputwrapper ng-tns-c59-1 ng-tns-c40-4 ng-untouched ng-pristine ng-valid ng-star-inserted p-inputwrapper-filled&quot;]/div[@class=&quot;ng-tns-c40-4 p-dropdown p-component&quot;]/div[@class=&quot;p-dropdown-trigger ng-tns-c40-4&quot;]/span[@class=&quot;p-dropdown-trigger-icon ng-tns-c40-4 pi pi-chevron-down&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/p-dropdown/div/div[2]/span</value>
   </webElementXpaths>
</WebElementEntity>
