<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Th loi_p-dropdown-trigger-icon ng-tns-_661ed7</name>
   <tag></tag>
   <elementGuidId>de103c0c-587a-4e27-9554-52003826a07b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.p-dropdown-trigger-icon.ng-tns-c40-3.pi.pi-chevron-down</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-dropdown-trigger-icon ng-tns-c40-3 pi pi-chevron-down</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-home-page[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;home ng-tns-c59-1&quot;]/div[@class=&quot;home-container ng-tns-c59-1&quot;]/div[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;filter-container ng-tns-c59-1&quot;]/div[@class=&quot;dropdown ng-tns-c59-1&quot;]/p-dropdown[@class=&quot;p-element p-inputwrapper ng-tns-c59-1 ng-tns-c40-3 ng-untouched ng-pristine ng-valid ng-star-inserted p-inputwrapper-filled&quot;]/div[@class=&quot;ng-tns-c40-3 filter-dropdown p-dropdown p-component&quot;]/div[@class=&quot;p-dropdown-trigger ng-tns-c40-3&quot;]/span[@class=&quot;p-dropdown-trigger-icon ng-tns-c40-3 pi pi-chevron-down&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span</value>
   </webElementXpaths>
</WebElementEntity>
