<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Th loi_p-dropdown-trigger ng-tns-c40-3</name>
   <tag></tag>
   <elementGuidId>be7794ba-baed-4254-88ae-3ee100fbb330</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.p-dropdown-trigger.ng-tns-c40-3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Thể loại'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-haspopup</name>
      <type>Main</type>
      <value>listbox</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-dropdown-trigger ng-tns-c40-3</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-home-page[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;home ng-tns-c59-1&quot;]/div[@class=&quot;home-container ng-tns-c59-1&quot;]/div[@class=&quot;ng-tns-c59-1 ng-star-inserted&quot;]/div[@class=&quot;filter-container ng-tns-c59-1&quot;]/div[@class=&quot;dropdown ng-tns-c59-1&quot;]/p-dropdown[@class=&quot;p-element p-inputwrapper ng-tns-c59-1 ng-tns-c40-3 ng-untouched ng-pristine ng-valid ng-star-inserted p-inputwrapper-filled&quot;]/div[@class=&quot;ng-tns-c40-3 filter-dropdown p-dropdown p-component&quot;]/div[@class=&quot;p-dropdown-trigger ng-tns-c40-3&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thể loại'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Xem Review'])[32]/following::div[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quốc gia'])[1]/preceding::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Năm phát hành'])[1]/preceding::div[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p-dropdown/div/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
