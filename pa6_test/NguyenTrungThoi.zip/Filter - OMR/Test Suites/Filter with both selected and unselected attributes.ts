<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Filter with both selected and unselected attributes</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>17bf53d5-50dc-4332-b54b-b9971fc81b21</testSuiteGuid>
   <testCaseLink>
      <guid>750b67fa-1029-4af0-9079-74433ed82552</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with both selected and unselected attributes/input1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7a5b0465-7d80-4b56-830f-d75e5d61f1a9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with both selected and unselected attributes/input2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>44b5b761-3be5-4b20-aff6-a00ed6f2b285</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with both selected and unselected attributes/input3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>37e5ca7b-a6c4-4f4b-94d0-c75cf248797f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with both selected and unselected attributes/input4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4554f317-e19b-4868-9a4b-a9fa74842029</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with both selected and unselected attributes/input5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
