<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Filter with all selected attributes</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>4d14be59-171f-4155-9a47-5d7f777702c5</testSuiteGuid>
   <testCaseLink>
      <guid>23c3802e-2adf-4333-b74f-e34e4dafbfb7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with all selected attributes/input1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7383639b-5c1f-49f6-8cbf-6e1a713ecd46</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with all selected attributes/input2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e394ed8f-12dc-4a36-8158-47b83d440f3e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with all selected attributes/input3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>df516376-2b0b-486e-9487-4b4db4718c07</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with all selected attributes/input4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>df9ce2e4-f2f5-45fc-8c4d-adef042e95f0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter with all selected attributes/input5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
